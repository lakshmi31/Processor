package com.card.processor;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import com.card.constant.Constants;
import com.card.destination.model.ResponseFromDestination;
import com.card.dozer.DozerMapping;
import com.card.source.model.Response;

public class ProducerBeanProcessor {
    /** Logger. */
    private static final Logger LOG = LoggerFactory.getLogger(ProducerBeanProcessor.class);
    /** dozerMapping initialization. */
    @Autowired
    private DozerMapping dozerMapping;
    /** Initialization of ResponseFromDestination class. */
    @Autowired
    private ResponseFromDestination responseFromDestination;
    /** Method returns the destination customer object.
     * 
     * @param exchange message in exchange
     * @throws Exception exception thrown */
    public void producerProcess(Exchange exchange) throws Exception {
        LOG.info("In Producer Processor....");
        String responseData = null;
        if (!StringUtils.isEmpty(exchange) && !StringUtils.isEmpty(exchange.getIn().getBody())) {
            if ((exchange.getIn().getBody()) instanceof String) {
                responseData = exchange.getIn().getBody().toString();
            } else {
                responseData = new String((byte[]) exchange.getIn().getBody(), "UTF-8");
            }
            LOG.info("Response Data:" + responseData);
            responseFromDestination.setSuccessMessage(responseData.substring(0, Constants.SUCCESS_MESSAGE_LENGTH));
            responseFromDestination.setErrorCode(responseData.substring(Constants.ERROR_MESSAGE_START,
                    Constants.ERROR_MESSAGE_END));
            responseFromDestination.setSourceIdentifier(responseData.substring(
                    Constants.SOURCE_IDENTIFIER_MESSAGE_START, Constants.SOURCE_IDENTIFIER_MESSAGE_END));
            responseFromDestination.setCorrelationID(responseData.substring(Constants.CORRELATION_ID_MESSAGE_START,
                    Constants.CORRELATION_ID_MESSAGE_END));
        }

        Response response = dozerMapping.mappedObject(responseFromDestination);
        if (!StringUtils.isEmpty(response)) {
            exchange.getOut().setBody(response);
        }
    }
}
