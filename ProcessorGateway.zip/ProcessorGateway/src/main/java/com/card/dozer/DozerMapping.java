package com.card.dozer;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.card.destination.model.CustomerDestination;
import com.card.destination.model.ResponseFromDestination;
import com.card.source.model.Customer;
import com.card.source.model.Response;
/** Mapping class to map source object to Destination object. */
@Component
public class DozerMapping {

    /** Logger. */
    private static final Logger LOG = LoggerFactory.getLogger(DozerMapping.class);
    @Autowired
    private DozerBeanMapper dozerBean;
    /** Method produce mapped object of CustomerDestination.
     * @param customer object
     * @return customerDestination object */
    public CustomerDestination mappedObject(Customer customer) {
        CustomerDestination customerDestination = dozerBean.map(customer, CustomerDestination.class);
        LOG.info("Mapped object is:" + customerDestination);
        return customerDestination;
    }
    /** Method produce mapped object of Response.
     * @param responseFromDestination destination response object
     * @return customerResponse object */
    public Response mappedObject(ResponseFromDestination responseFromDestination) {
        Response response = dozerBean.map(responseFromDestination, Response.class);
        LOG.info("Mapped object is:" + response);
        return response;
    }
}
