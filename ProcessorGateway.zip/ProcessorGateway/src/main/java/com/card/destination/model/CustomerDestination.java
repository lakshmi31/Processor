package com.card.destination.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/** POJO class for mapping incoming JSON request for Customer. */
@Component
public class CustomerDestination implements Serializable {

    /** Serial version default ID. */
    private static final long serialVersionUID = 1L;
    /** firstName. */
    private String firstName;
    /** lastName. */
    private String lastName;
    /** mobileNumber. */
    private String mobileNumber;
    /** emailAddress. */
    private String emailAddress;
    /** dob. */
    private String dob;
    /** buildingName. */
    private String buildingName;
    /** streetName. */
    private String streetName;
    /** postalCode. */
    private String postalCode;
    /** Source Identifier. */
    private String sourceIdentifier;
    /** Correlation ID. */
   /* @JsonProperty("id")*/
    private String correlationID;

    /** @return the firstName. */
    public String getFirstName() {
        return firstName;
    }
    /** @param firstName the firstName to set. */
    public void setFirstName(String firstName) {
        this.firstName = String.format("%1$" + 25 + "s", firstName);
    }
    /** @return the lastName. */
    public String getLastName() {
        return lastName;
    }
    /** @param lastName the lastName to set. */
    public void setLastName(String lastName) {
        this.lastName = String.format("%1$" + 25 + "s", lastName);
    }
    /** @return the mobileNumber. */
    public String getMobileNumber() {
        return mobileNumber;
    }
    /** @param mobileNumber the mobileNumber to set. */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = String.format("%1$" + 14 + "s", mobileNumber);
    }
    /** @return the emailAddress. */
    public String getEmailAddress() {
        return emailAddress;
    }
    /** @param emailAddress the emailAddress to set. */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = String.format("%1$" + 128 + "s", emailAddress);
    }
    /** @return the dob. */
    public String getDob() {
        return dob;
    }
    /** @param dob the dob to set. */
    public void setDob(String dob) {
        this.dob = String.format("%1$" + 10 + "s", dob);
    }
    /** @return the buildingName. */
    public String getBuildingName() {
        return buildingName;
    }
    /** @param buildingName the buildingName to set. */
    public void setBuildingName(String buildingName) {
        this.buildingName = String.format("%1$" + 30 + "s", buildingName);
    }
    /** @return the streetName. */
    public String getStreetName() {
        return streetName;
    }
    /** @param streetName the streetName to set. */
    public void setStreetName(String streetName) {
        this.streetName = String.format("%1$" + 25 + "s", streetName);
    }
    /** @return the postalCode. */
    public String getPostalCode() {
        return postalCode;
    }
    /** @param postalCode the postalCode to set. */
    public void setPostalCode(String postalCode) {
        this.postalCode = String.format("%1$" + 8 + "s", postalCode);
    }
    /** @return the sourceIdentifier. */
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }
    /** @param sourceIdentifier the sourceIdentifier to set. */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = String.format("%1$" + 15 + "s", sourceIdentifier);
    }
    /** @return the correlationID. */
    public String getCorrelationID() {
        return correlationID;
    }
    /** @param correlationID the correlationID to set. */
    public void setCorrelationID(String correlationID) {
        this.correlationID = String.format("%1$" + 36 + "s", correlationID);
    }
    /** @param firstName customer firstName.
     * @param lastName customer lastName
     * @param mobileNumber customer mobile
     * @param emailAddress customer email
     * @param dob customer DOB
     * @param buildingName Address buildingName
     * @param streetName Address streetName
     * @param postalCode Address postalCode
     * @param sourceIdentifier Source Identification ID
     * @param correlationID Correlation ID */
    public CustomerDestination(String firstName, String lastName, String mobileNumber, String emailAddress, String dob,
            String buildingName, String streetName, String postalCode, String sourceIdentifier, String correlationID) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNumber = mobileNumber;
        this.emailAddress = emailAddress;
        this.dob = dob;
        this.buildingName = buildingName;
        this.streetName = streetName;
        this.postalCode = postalCode;
        this.sourceIdentifier = sourceIdentifier;
        this.correlationID = correlationID;
    }
    /** Default Constructor. */
    public CustomerDestination() {
    }
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return correlationID + "" + firstName + "" + lastName + "" + mobileNumber + "" + emailAddress + "" + dob + "" + buildingName
                + "" + streetName + "" + postalCode + "" + sourceIdentifier;
    }

}
