package com.card.destination.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/** Customer data POJO for Response.
 * @author ldudhbha */
@Component
public class ResponseFromDestination implements Serializable {
    /** Serialization default ID. */
    private static final long serialVersionUID = 1L;
    /** Response Success Message. */
    private String successMessage;
    /** Response Error code. */
    private String errorCode;
    /** Source Identifier. */
    private String sourceIdentifier;
    /** Correlation ID. */
    private String correlationID;

    /** @return the errorCode. */
    public String getErrorCode() {
        return errorCode;
    }
    /** @param errorCode the errorCode to set. */
    public void setErrorCode(String errorCode) {
        this.errorCode = String.format("%1$" + 4 + "s", errorCode);
    }
    /** @return the successMessage. */
    public String getSuccessMessage() {
        return successMessage;
    }
    /** @param successMessage the successMessage to set. */
    public void setSuccessMessage(String successMessage) {
        this.successMessage = String.format("%1$" + 7 + "s", successMessage);
    }
    /** @return the sourceIdentifier. */
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }
    /** @param sourceIdentifier the sourceIdentifier to set. */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = String.format("%1$" + 15 + "s", sourceIdentifier);
    }
    /** @return the correlationID. */
    public String getCorrelationID() {
        return correlationID;
    }
    /** @param correlationID the correlationID to set. */
    public void setCorrelationID(String correlationID) {
        this.correlationID = String.format("%1$" + 36 + "s", correlationID);
    }
    /** @param errorCode response error code.
     * @param successMessage response success message
     * @param sourceIdentifier source identification ID
     * @param correlationID correlation ID */
    public ResponseFromDestination(String errorCode, String successMessage, String sourceIdentifier,
            String correlationID) {
        super();
        this.errorCode = errorCode;
        this.successMessage = successMessage;
        this.sourceIdentifier = sourceIdentifier;
        this.correlationID = correlationID;
    }
    /** Default Constructor. */
    public ResponseFromDestination() {

    }
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return successMessage + "" + errorCode + "" + sourceIdentifier + "" + correlationID;
    }

}
