/*package com.card.test.router;

import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
public class RouterJUnitTest extends CamelTestSupport {
    @Before
    public void setup() throws Exception {
        super.setUp();

    }
    @Test
    public void testIntegrationRoute() throws Exception {

        final String json = "\"{\"correlationID\":\"4f66350c-1741-42d9-9689-6ff0ab2b374e\",\"firstName\":\"Abhishek\",\"lastName\":\"Patel\",\"mobileNumber\":\"99999\",\"emailAddress\":\"abhishek.patel@gmail.com\",\"address\":{\"buildingName\":\"B1\",\"streetName\":\"S1\",\"pincode\":\"123\"},\"dob\":1495182516453,\"sourceIdentifier\":\"rabbitMQ\"}";
        context.createConsumerTemplate().receiveBody("timer://event?fixedRate=true&period=30000");
        context.createProducerTemplate().sendBody("http://10.217.100.253:5223/consumer/getMessage?method=get", json);

        // Initialize the mock and set expected results
        MockEndpoint mock = context.getEndpoint("mock:excpectedRequest", MockEndpoint.class);
        mock.expectedMessageCount(1);

        mock.assertIsSatisfied();
    }

}
*/